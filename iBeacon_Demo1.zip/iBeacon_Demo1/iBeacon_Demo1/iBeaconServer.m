//
//  iBeaconServer.m
//  iBeacon_Demo1
//
//  Created by ZhangCheng on 14-5-29.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "iBeaconServer.h"

@implementation iBeaconServer
-(id)init{
    if (self=[super init]) {
        NSUUID*uuid=[[NSUUID alloc]initWithUUIDString:KUUID];
        CLBeaconMajorValue major= 45;
        CLBeaconMinorValue minor= arc4random()%1000;
        myBeaconRegion=[[CLBeaconRegion alloc]initWithProximityUUID:uuid major:major minor:minor identifier:[[NSBundle mainBundle] bundleIdentifier]];
        myBeaconData=[myBeaconRegion peripheralDataWithMeasuredPower:nil];
        [myBeaconData retain];
        peripheralMsg=[[CBPeripheralManager alloc]initWithDelegate:self queue:dispatch_get_main_queue() options:nil];
        
        
    }
    return self;

}

//状态变化
-(void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral
{
    NSLog(@"服务端状态有变化");
    if (peripheral.state==CBPeripheralManagerStatePoweredOn) {
        
        [peripheralMsg startAdvertising:myBeaconData];
    }else{
        
        if (peripheral.state==CBPeripheralManagerStatePoweredOff) {
            [peripheral stopAdvertising];
        }
    }
}
@end
