//
//  iBeaconClient.h
//  iBeacon_Demo1
//
//  Created by ZhangCheng on 14-5-29.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <CoreLocation/CoreLocation.h>
#import "ZCViewController.h"
@interface iBeaconClient : NSObject<CLLocationManagerDelegate>
{
    CLLocationManager*locationManager;
    CLBeaconRegion *myBeaconRegion;
}
@property(nonatomic,assign)ZCViewController*vc;
@property(nonatomic,retain)NSMutableDictionary*dataArray;
@end
