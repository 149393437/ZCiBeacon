//
//  iBeaconServer.h
//  iBeacon_Demo1
//
//  Created by ZhangCheng on 14-5-29.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "ZCViewController.h"
@interface iBeaconServer : NSObject<CLLocationManagerDelegate,CBPeripheralManagerDelegate>
{
    CLBeaconRegion*myBeaconRegion;
    NSMutableDictionary*myBeaconData;
    CBPeripheralManager*peripheralMsg;
}
@property(nonatomic,assign)ZCViewController*vc;
@end
