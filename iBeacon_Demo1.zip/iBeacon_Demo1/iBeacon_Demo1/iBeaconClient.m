//
//  iBeaconClient.m
//  iBeacon_Demo1
//
//  Created by ZhangCheng on 14-5-29.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "iBeaconClient.h"

@implementation iBeaconClient
-(id)init{
    if (self=[super init]) {
        /*
         后台挂起
         然后在plist文件中添加Required background modes选项，增加三个值
         App communicates using CoreBluetooth，App shares data using CoreBluetooth，App registers for location updates
         并且- (void)locationManager:(CLLocationManager *)manager
         didRangeBeacons:(NSArray *)beacons
         inRegion:(CLBeaconRegion *)region;
需要在appdelegate里面实现
         */
        //NSLocationAlwaysUsageDescription   NSLocationWhenInUseUsageDescription
        self.dataArray=[NSMutableDictionary dictionaryWithCapacity:0];
        locationManager=[[CLLocationManager alloc]init];
        locationManager.delegate=self;
        [locationManager requestAlwaysAuthorization];
        [locationManager requestWhenInUseAuthorization];
        //@"E2C56DB5-DFFB-48D2-B060-D0F5A71096E4"
        NSUUID*uuid=[[NSUUID alloc]initWithUUIDString:KUUID];
        myBeaconRegion=[[CLBeaconRegion alloc]initWithProximityUUID:uuid identifier:[[NSBundle mainBundle] bundleIdentifier]];
        [locationManager startMonitoringForRegion:myBeaconRegion];
        [locationManager requestStateForRegion:myBeaconRegion];
        [locationManager startRangingBeaconsInRegion:myBeaconRegion];
       
    }
    return self;
}


//屏幕点亮时候 如果设备在一个beacon内会调用，不论用户是否在前台或者后台或者kill
-(void)locationManager:(CLLocationManager *)manager didDetermineState:(CLRegionState)state forRegion:(CLRegion *)region
{
    if (state==CLRegionStateInside) {
        NSLog(@"在里面");
    }
    if (state==CLRegionStateOutside) {
        NSLog(@"外面");
    }

}
//获得每次定位的距离以及相关CLBeacon的数据
-(void)locationManager:(CLLocationManager *)manager didRangeBeacons:(NSArray *)beacons inRegion:(CLBeaconRegion *)region
{
    
    NSLog(@"扫描中。。。。。%ld",(unsigned long)beacons.count);
    NSInteger num=[self.dataArray allKeys].count;
    
    for (CLBeacon *beacon in beacons) {
        NSString*str=[self modelToString:beacon];
        [self.dataArray setObject:str forKey:[beacon.minor stringValue]];
        
      UITextView*textView=  (UITextView*)[self.vc.view viewWithTag:[beacon.minor integerValue]];
        if (textView) {
            textView.text=str;
        }else{
           textView= [self.vc createTextViewFrame:CGRectMake(num%3*100, num/3*210, 90, 200) text:str];
            textView.tag=[beacon.minor integerValue];
            
            
            num++;
        }
        
    }
    
  //  NSLog(@"%@",self.dataArray);
  
    
    
}
-(NSString*)modelToString:(CLBeacon*)beacon{
    NSLog(@"最近多少米%0.4f",beacon.accuracy);
    NSString*str=[NSString stringWithFormat:@"uuid %@ \n",beacon.proximityUUID.UUIDString];
    NSString*str1=[NSString stringWithFormat:@"主频 %@\n",beacon.major];
    NSString*str2=[NSString stringWithFormat:@"副频 %@\n",beacon.minor];
    NSString*str3=[NSString stringWithFormat:@"接近程度~%ld\n",(long)beacon.proximity];
    NSString*str4=[NSString stringWithFormat:@"距离我多远 %0.4f\n",beacon.accuracy];
    NSString*str5=[NSString stringWithFormat:@"信号强度~%ld\n",(long)beacon.rssi];
    NSString*strAll=[NSString stringWithFormat:@"%@%@%@%@%@%@",str,str1,str2,str3,str4,str5];
    return strAll;
}
//启动iBeacon服务错误（通常需要重启手机才可以）
-(void)locationManager:(CLLocationManager *)manager rangingBeaconsDidFailForRegion:(CLBeaconRegion *)region withError:(NSError *)error
{
    NSLog(@"开启失败");

}

//进入到某一个iBeacon范围内，在后台同样可以收到，然后发起网络请求
-(void)locationManager:(CLLocationManager *)manager didEnterRegion:(CLRegion *)region
{
    NSLog(@"进入区域");
}
//离开某一个iBeacon范围内
-(void)locationManager:(CLLocationManager *)manager didExitRegion:(CLRegion *)region
{
    NSLog(@"离开区域");
}
@end
