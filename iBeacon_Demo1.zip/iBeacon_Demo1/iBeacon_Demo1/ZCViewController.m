
//
//  ZCViewController.m
//  iBeacon_Demo1
//
//  Created by ZhangCheng on 14-5-29.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import "ZCViewController.h"
#import "iBeaconClient.h"
#import "iBeaconServer.h"
@interface ZCViewController ()

@end

@implementation ZCViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
  //  [self createTextView];
    iBeaconClient *aa=[[iBeaconClient alloc]init];
    aa.vc=self;
    iBeaconServer *bb=[[iBeaconServer alloc]init];
    bb.vc=self;
    
    
    // Do any additional setup after loading the view.
}
-(UITextView*)createTextViewFrame:(CGRect)frame text:(NSString*)text{
    UITextView*textView=[[UITextView alloc]initWithFrame:frame];
    [self.view addSubview:textView];
    [textView release];
    textView.backgroundColor=[UIColor blackColor];
    textView.textColor=[UIColor whiteColor];
    textView.text=text;
    
    return textView;
}

-(void)createTextView{
    _textView=[[UITextView alloc]initWithFrame:CGRectMake(50, 100, 220, 200)];
    [self.view addSubview:_textView];
    [_textView release];
    _textView.backgroundColor=[UIColor blackColor];
    _textView.textColor=[UIColor whiteColor];

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
